'''http://kidscancode.org/lessons/?fbclid=IwAR3bXfUecbV2BWCurFSbvMfKNFjWYYMEBJjyLWuZy1TA_9EkTx9jp0M28fA

import pygame, sys
from pygame.locals import QUIT

pygame.init()
DISPLAYSURF = pygame.display.set_mode((400, 300))
pygame.display.set_caption('Hello World!')
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
    pygame.display.update()'''


import random, pygame
from os import path


width = 520
height = 370
FPS = 60

#Constants
SHOOTDELAY = 200
POWERUPTIME = 5000


#Colours
white = (255,255,255)
black = (0,0,0)
red = (255,0,0)
green = (0,255,0)
blue = (0,0,255)
yellow = (255, 255, 0)

#set up assets (art,sound for game) folders
img_dir = path.join(path.dirname(__file__), 'assets')
snd_dir = path.join(path.dirname(__file__), 'sounds')

#initialise pygame and creates the window 
pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode ((width, height ))
pygame.display.set_caption("Shmup")
clock = pygame.time.Clock()


#functions and dat
fontName = pygame.font.match_font('arial')
def drawText(surf, text, size, x, y):
  font = pygame.font.Font(fontName, size)
  text_surface = font.render(text, True, white)
  text_rect = text_surface.get_rect()
  text_rect.midtop = (x, y)
  surf.blit(text_surface, text_rect)

def newMob():
  m = Mob()
  all_sprites.add(m)
  mobs.add(m)

def draw_shield_bar(surf, x, y, pct):
  if pct < 0:
    pct = 0
  BAR_LENGTH = 100
  BAR_HEIGHT = 10
  fill = (pct / 100) * BAR_LENGTH
  outline_rect = pygame.Rect(x, y, BAR_LENGTH, BAR_HEIGHT)
  fill_rect = pygame.Rect(x, y, fill, BAR_HEIGHT)
  pygame.draw.rect(surf, green, fill_rect)
  pygame.draw.rect(surf, white, outline_rect, 2)

def draw_lives(surf, x, y, lives, img):
  for i in range(lives):
    img_rect = img.get_rect()
    img_rect.x = x + 30 * i
    img_rect.y = y
    surf.blit(img, img_rect)
    

class Player(pygame.sprite.Sprite):
    #sprite (object on screen) for Player
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(player_img, (40, 30))  
        self.image.set_colorkey(black)
        self.rect = self.image.get_rect() 
        self.radius = 17
        # pygame.draw.circle(self.image, red, self.rect.center, self.radius)
        self.rect.centerx = (width / 2)
        self.rect.bottom = (height - 10)
        self.x_speed = 0
        self.shield = 100 
        self.lastShot = pygame.time.get_ticks()
        self.lives = 3
        self.hidden = False
        self.hide_timer = pygame.time.get_ticks()
        self.power = 1
        self.power_time = pygame.time.get_ticks()

    def update(self): 
      #timeout for powerups 
      if self.power > 1 and pygame.time.get_ticks() - self.power_time > POWERUPTIME:
        self.power -= 1
        self.power_time = pygame.time.get_ticks()
        
      #unhide yet?
      if (self.hidden) and (pygame.time.get_ticks() - self.hide_timer >              1000):
        self.hidden = False
        self.rect.centerx = (width / 2)
        self.rect.bottom = (height - 10)
        
      self.x_speed = 0
      keystate = pygame.key.get_pressed()
      if keystate[pygame.K_SPACE]:
        self.shoot()
      if keystate[pygame.K_LEFT]:
        self.x_speed = -4
      if keystate[pygame.K_RIGHT]:
        self.x_speed = 4
      self.rect.x += self.x_speed
      if self.rect.right > width:
        self.rect.right = width
      if self.rect.left < 0:
        self.rect.left = 0

    def shoot(self):
      now = pygame.time.get_ticks()
      if (now - self.lastShot) >= SHOOTDELAY:
        self.lastShot = now
        if self.power == 1:
          bullet = Bullet(self.rect.centerx, self.rect.top)
          all_sprites.add(bullet)
          bullets.add(bullet)
          shoot_sound.play()
        if self.power >= 2:
          bullet1 = Bullet(self.rect.left, self.rect.centery)
          bullet2 = Bullet(self.rect.right, self.rect.centery)
          all_sprites.add(bullet1)
          all_sprites.add(bullet2)
          bullets.add(bullet1)
          bullets.add(bullet2)
          shoot_sound.play()
  
    def powerup(self):
      self.power += 1
      self.power_time = pygame.time.get_ticks()
  
    def hide(self):
      #hide player temporarily
      self.hidden = True
      self.hide_timer = pygame.time.get_ticks()
      self.rect.center = (width / 2, height + 200)
      
class Mob(pygame.sprite.Sprite):
  def __init__(self):
    pygame.sprite.Sprite.__init__(self)
    self.image_orig = random.choice(meteor_images)
    self.image_orig.set_colorkey(black)
    self.image = self.image_orig.copy()
    self.rect = self.image.get_rect()
    self.radius = int(self.rect.width * 0.85 / 2)
    # pygame.draw.circle(self.image, red, self.rect.center, self.radius)
    self.rect.x = random.randrange(width - self.rect.width)
    self.rect.y = random.randrange(-200,-150)
    self.y_speed = random.randrange(1,4)
    self.x_speed = random.randrange(-3, 3)
    self.rot = 0
    self.rot_speed = random.randrange(-8, 8)
    self.last_update = pygame.time.get_ticks()

  def rotate(self):
    now = pygame.time.get_ticks()
    if now - self.last_update > 50:
      self.last_update = now
      self.rot = (self.rot + self.rot_speed)% 360
      new_image = pygame.transform.rotate(self.image_orig, self.rot)
      old_center = self.rect.center
      self.image = new_image
      self.rect = self.image.get_rect()
      self.rect.center = old_center
      
    
  def update(self):
    self.rotate()
    self.rect.y += self.y_speed
    self.rect.x += self.x_speed
    if self.rect.top > height + 10 or self.rect.left < -25 or self.rect.right > width + 20:
      self.rect.x = random.randrange(width - self.rect.width)
      self.rect.y = random.randrange(-100,-40)
      self.y_speed = random.randrange(1,8)

class Bullet(pygame.sprite.Sprite):
  def __init__(self, x ,y):
    pygame.sprite.Sprite.__init__(self)
    self.image = bullet_img
    self.image.set_colorkey(black)
    self.rect = self.image.get_rect()
    self.rect.bottom = y
    self.rect.centerx = x
    self.y_speed = -10 
  

  def update(self):
    self.rect.y += self.y_speed
    #kill if it moves off the top of the screen
    if self.rect.bottom < 0:
      self.kill()

class Pow(pygame.sprite.Sprite):
  def __init__(self,center):
    pygame.sprite.Sprite.__init__(self)
    self.type = random.choice(["shield", "gun"])
    self.image = powerup_imgs[self.type]
    self.image.set_colorkey(black)
    self.rect = self.image.get_rect()
    self.rect.center = center
    self.y_speed = 3
  
  
  def update(self):
    self.rect.y += self.y_speed
    #kill if it moves off the top of the screen
    if self.rect.top > height:
      self.kill()

class Explosion(pygame.sprite.Sprite):
  def __init__(self, center, size):
    pygame.sprite.Sprite.__init__(self)
    self.size = size
    self.image = expl_anim[self.size][0]
    self.rect = self.image.get_rect()
    self.rect.center = center
    self.frame = 0
    self.last_update = pygame.time.get_ticks()
    self.frame_rate = 75 
    
  def update(self):
    now = pygame.time.get_ticks()
    if (now - self.last_update) > self.frame:
      self.last_update = now 
      self.frame += 1
      if self.frame == len(expl_anim[self.size]):
        self.kill()
      else: 
        center = self.rect.center
        self.image = expl_anim[self.size][self.frame]
        self.rect = self.image.get_rect()
        self.rect.center = center 
        
def show_go_screen():
  screen.blit(background, background_rect)
  drawText(screen, "SHMUP!", 64, width / 2, height / 4)
  drawText(screen, "Arrow keys to move", 18, width / 2, height / 2)
  drawText(screen, "Space to fire", 18, width / 2, height / 2 + 23)
  drawText(screen, "Press a key to begin", 18, width / 2, height * 3 / 4)
  pygame.display.flip()
  waiting = True
  while waiting:
    clock.tick(FPS)
    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        pygame.quit()
      if event.type == pygame.KEYUP:
        waiting = False
      
#load all game graphics
background = pygame.image.load("assets/base/starfield.png").convert()
background_rect = background.get_rect()
player_img = pygame.image.load("assets/base/ship.png").convert()
player_mini_img = pygame.transform.scale(player_img, (25, 19))
player_mini_img.set_colorkey(black)
bullet_img = pygame.image.load("assets/base/bullet.png").convert()
meteor_images = []
meteor_list = ["meteorBrown_big1.png", "meteorBrown_big2.png",              
               "meteorBrown_med1.png", "meteorBrown_med2.png", 
               "meteorBrown_small1.png", "meteorBrown_small2.png", 
               "meteorBrown_tiny1.png"]
  
for img in meteor_list:
  meteor_images.append(pygame.image.load(path.join(img_dir, "meteors/" + img)).convert())

expl_anim = {}
expl_anim["lg"] = []
expl_anim["sm"] = []
expl_anim['player'] = []
for i in range(9):
  filename = "regularExplosion0{}.png".format(i)
  img = pygame.image.load(path.join(img_dir, "expl/meteor/" + filename)).convert()
  img.set_colorkey(black)
  img_lg = pygame.transform.scale(img, (75, 75))
  expl_anim["lg"].append(img_lg)
  img_sm = pygame.transform.scale(img, (32, 32))
  expl_anim["sm"].append(img_sm)
  filename = "sonicExplosion0{}.png".format(i)
  img_ship = pygame.image.load(path.join(img_dir, "expl/ship/" + filename)).convert()
  img_ship.set_colorkey(black)
  expl_anim["player"].append(img_ship)

powerup_imgs = {}
powerup_imgs['shield'] = pygame.image.load(path.join(img_dir, "pow/shield.png")).convert()
powerup_imgs['gun'] = pygame.image.load(path.join(img_dir, "pow/bolt.png")).convert()

#load all sounds
shoot_sound = pygame.mixer.Sound(path.join(snd_dir, "pew.wav"))
# different file???????
shield = pygame.mixer.Sound(path.join(snd_dir, "shield.ogg"))
power = pygame.mixer.Sound(path.join(snd_dir, "laser.ogg"))
expl_sounds = []
for snd in ['expl3.wav', 'expl6.wav']:
  expl_sounds.append(pygame.mixer.Sound(path.join(snd_dir, snd)))
player_die_sound = pygame.mixer.Sound(path.join(snd_dir, 'rumble1.ogg'))
pygame.mixer.music.load(path.join(snd_dir, "backgroundMusic.ogg"))
pygame.mixer.music.set_volume(0.3)
pygame.mixer.music.play(loops= -1)



#Game loop
gameOver = True
running = True 
while running:  
  if gameOver:
    show_go_screen()
    gameOver = False
    all_sprites = pygame.sprite.Group()
    bullets = pygame.sprite.Group()
    powerups = pygame.sprite.Group()
    mobs = pygame.sprite.Group()
    player = Player() 
    all_sprites.add(player)
    for i in range(15):
      newMob()
    score = 0 
  #keep loop running at the right speed
  clock.tick(FPS)
  #Process input (events)
  for event in pygame.event.get():
      #check for closing window (x)
      if event.type == pygame.QUIT:
          running = False
        
  
  #Update 
  all_sprites.update()
  
  #check if a bullet hits mob
  hits = pygame.sprite.groupcollide(mobs, bullets, True, True)
  for hit in hits:
    score += int(200 / hit.radius)
    random.choice(expl_sounds).play()
    expl = Explosion(hit.rect.center, "lg")
    all_sprites.add(expl)
    if random.random() > 0.9:
      pow = Pow(hit.rect.center)
      all_sprites.add(pow)
      powerups.add(pow)
    newMob()


  #check to see if player hits powerup 
  hits = pygame.sprite.spritecollide(player, powerups, True)
  for hit in hits:
    if hit.type == "shield":
      player.shield += random.randrange(10,25)
      shield.play()
      if player.shield > 100:
        player.shield = 100
    if hit.type == "gun":
      player.powerup()
      power.play()
  
  #check to see if mob hits player
  hits = pygame.sprite.spritecollide(player, mobs, True, pygame.sprite.collide_circle)
  for hit in hits:
    player.shield -= hit.radius * 2
    expl = Explosion(hit.rect.center, "sm")
    all_sprites.add(expl)
    newMob()
    if player.shield <= 0:
      player_die_sound.play()
      death_expl = Explosion(player.rect.center, "player")
      all_sprites.add(death_expl)
      player.hide()
      player.lives -= 1
      player.shield = 100
    
  #check if player has died and explosion has finished too 
  if (player.lives == 0) and (not death_expl.alive()):
    gameOver = True
  
  #Draw / Render 
  screen.fill(black)
  screen.blit(background, background_rect)
  all_sprites.draw(screen)
  drawText(screen, str(score), 18, width / 2, 10)
  draw_shield_bar(screen, 5, 5, player.shield)
  draw_lives(screen, width - 100, 5, player.lives, player_mini_img)
  
  #do this after drawing everything (flip the display)
  pygame.display.flip()

'''with open("scores.csv", "a") as f:
  f.writelines (str(score))
pygame.quit()

a = 0
i = 0
with open("scores.csv", "r") as f:
  while True:
    score = f.read()
    score = int(score)
    if score > a:
      a = score
    elif score == "":
      break
    i += 1
print(a)'''
pygame.quit()